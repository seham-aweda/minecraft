let maincontainer = document.querySelector(`.maincontainer`),
  btncontainer = document.querySelector(`.btncontainer`),
  btnstartgame = document.querySelector(`.btnstart`),
  btnsmall = document.querySelector(`.btnsmall`),
  btnbig = document.querySelector(`.btnbig`);
smallmapmain = document.querySelector(`.smallmapmain`),
  bigmapmain = document.querySelector(`.bigmapmain`),
  toMain = document.querySelectorAll(`.return`),
  refresh = document.querySelectorAll(`.refresh`),
  btnbig = document.querySelector(`.btnbig`);


  ////////// activating buttons/////////////
maincontainer.style.display = "block";
smallmapmain.style.display = "none";
bigmapmain.style.display = "none";

btnsmall.addEventListener(`click`, () => {
  maincontainer.style.display = "none";
  bigmapmain.style.display = "none";
  smallmapmain.style.display = "grid";
});

btnbig.addEventListener(`click`, () => {
  bigmapmain.style.display = "grid";
  smallmapmain.style.display = "none";
  maincontainer.style.display = "none";
});

btnstartgame.addEventListener(`click`, () => {
  maincontainer.style.display = "none";
  smallmapmain.style.display = "grid";
  bigmapmain.style.display = "none";
});
for (let page = 0; page < toMain.length; page++) {
  toMain[page].addEventListener(`click`, () => {
    maincontainer.style.display = "grid";
    bigmapmain.style.display = "none";
    smallmapmain.style.display = "none";
  });
}
for (let page = 0; page < refresh.length; page++) {
  refresh[page].addEventListener(`click`, () => {
    maincontainer.style.display = "none";
    bigmapmain.style.display = "none";
    smallmapmain.style.display = "grid";
  });
}

////////////position the elements////////////
// function randomGridPosition() {
//   return {
//     x: Math.floor(Math.random() * GRID_SIZE) + 1,
//     y: Math.floor(Math.random() * GRID_SIZE) + 1,
//   };
// }

const smallgameBoard=[
  [0,0,0,0,0,0,0,0,0,0],
  [0,0,1,1,0,0,0,1,0,0],
  [0,0,1,0,0,0,1,1,0,0],
  [0,0,0,2,2,0,0,1,0,0],
  [0,0,2,2,2,0,0,0,0,4],
  [0,0,2,2,2,0,0,0,4,4],
  [0,0,0,3,0,0,0,0,4,4],
  [0,0,0,3,0,5,5,5,5,5],
  [5,5,5,5,5,6,6,6,6,6],
  [7,7,7,7,7,7,7,7,7,7]
]

function types(data){
  for(let row=0;row<data.length;row++){
    for(let column=0; column<data.length[i];column++){
      if(data[row][column]==0({
        
      })
    }
  }
}